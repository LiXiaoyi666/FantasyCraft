
package net.mcreator.fantasycraft.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Squid1Item extends Item {
	public Squid1Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
