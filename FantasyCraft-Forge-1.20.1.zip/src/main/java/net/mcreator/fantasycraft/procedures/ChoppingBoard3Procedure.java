package net.mcreator.fantasycraft.procedures;

import net.minecraft.world.level.LevelAccessor;

public class ChoppingBoard3Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		ChoppingBoard2Procedure.execute(world, x, y, z);
	}
}
