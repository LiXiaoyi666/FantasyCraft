
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.fantasycraft.block.entity.StoveBlockEntity;
import net.mcreator.fantasycraft.block.entity.ChoppingBoardBlockEntity;
import net.mcreator.fantasycraft.FantasycraftMod;

public class FantasycraftModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FantasycraftMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> CHOPPING_BOARD = register("chopping_board", FantasycraftModBlocks.CHOPPING_BOARD, ChoppingBoardBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> STOVE = register("stove", FantasycraftModBlocks.STOVE, StoveBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
