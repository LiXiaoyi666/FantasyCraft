
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fantasycraft.item.VinegarItem;
import net.mcreator.fantasycraft.item.VegetableoilItem;
import net.mcreator.fantasycraft.item.Squid3Item;
import net.mcreator.fantasycraft.item.Squid2Item;
import net.mcreator.fantasycraft.item.Squid1Item;
import net.mcreator.fantasycraft.item.SourAndSpicyShreddedPotatoesItem;
import net.mcreator.fantasycraft.item.RawShreddedSeaweedItem;
import net.mcreator.fantasycraft.item.RawShreddedPotatoItem;
import net.mcreator.fantasycraft.item.RawSeaweedKnotItem;
import net.mcreator.fantasycraft.item.RawPorkNuggetsItem;
import net.mcreator.fantasycraft.item.RawPlatinumItem;
import net.mcreator.fantasycraft.item.RawMuttonNuggetsItem;
import net.mcreator.fantasycraft.item.RawChickenNuggetsItem;
import net.mcreator.fantasycraft.item.RawBeefNuggetsItem;
import net.mcreator.fantasycraft.item.RawBaconItem;
import net.mcreator.fantasycraft.item.PrimaryvinegarItem;
import net.mcreator.fantasycraft.item.PlatinumSwordItem;
import net.mcreator.fantasycraft.item.PlatinumShovelItem;
import net.mcreator.fantasycraft.item.PlatinumPickaxeItem;
import net.mcreator.fantasycraft.item.PlatinumNuggetItem;
import net.mcreator.fantasycraft.item.PlatinumIngotItem;
import net.mcreator.fantasycraft.item.PlatinumHoeItem;
import net.mcreator.fantasycraft.item.PlatinumAxeItem;
import net.mcreator.fantasycraft.item.MayonnaiseItem;
import net.mcreator.fantasycraft.item.KitchenKnifeItem;
import net.mcreator.fantasycraft.item.HoneycombBriquetItem;
import net.mcreator.fantasycraft.item.HalfAnEggItem;
import net.mcreator.fantasycraft.item.FriedShreddedPotatoItem;
import net.mcreator.fantasycraft.item.Emptybottle4Item;
import net.mcreator.fantasycraft.item.Emptybottle3Item;
import net.mcreator.fantasycraft.item.Emptybottle2Item;
import net.mcreator.fantasycraft.item.Emptybottle1Item;
import net.mcreator.fantasycraft.item.EmeraldSwordItem;
import net.mcreator.fantasycraft.item.EmeraldSuitItem;
import net.mcreator.fantasycraft.item.EmeraldShovelItem;
import net.mcreator.fantasycraft.item.EmeraldPickaxeItem;
import net.mcreator.fantasycraft.item.EmeraldHoeItem;
import net.mcreator.fantasycraft.item.EmeraldAxeItem;
import net.mcreator.fantasycraft.item.CrudeoilItem;
import net.mcreator.fantasycraft.item.CopperSwordItem;
import net.mcreator.fantasycraft.item.CopperSuitItem;
import net.mcreator.fantasycraft.item.CopperShovelItem;
import net.mcreator.fantasycraft.item.CopperPickaxeItem;
import net.mcreator.fantasycraft.item.CopperHoeItem;
import net.mcreator.fantasycraft.item.CopperAxeItem;
import net.mcreator.fantasycraft.item.CookedShreddedSeaweedItem;
import net.mcreator.fantasycraft.item.CookedSeaweedKnotItem;
import net.mcreator.fantasycraft.item.CookedPorkNuggetsItem;
import net.mcreator.fantasycraft.item.CookedMuttonNuggetsItem;
import net.mcreator.fantasycraft.item.CookedEggItem;
import net.mcreator.fantasycraft.item.CookedChickenNuggetsItem;
import net.mcreator.fantasycraft.item.CookedBeefNuggetsItem;
import net.mcreator.fantasycraft.item.CookedBaconItem;
import net.mcreator.fantasycraft.item.ColdSeaweedSaladItem;
import net.mcreator.fantasycraft.item.CoalFragmentItem;
import net.mcreator.fantasycraft.item.Book1Item;
import net.mcreator.fantasycraft.FantasycraftMod;

public class FantasycraftModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FantasycraftMod.MODID);
	public static final RegistryObject<Item> VINEGAR = REGISTRY.register("vinegar", () -> new VinegarItem());
	public static final RegistryObject<Item> VEGETABLEOIL = REGISTRY.register("vegetableoil", () -> new VegetableoilItem());
	public static final RegistryObject<Item> SQUID_1 = REGISTRY.register("squid_1", () -> new Squid1Item());
	public static final RegistryObject<Item> SQUID_2 = REGISTRY.register("squid_2", () -> new Squid2Item());
	public static final RegistryObject<Item> SQUID_3 = REGISTRY.register("squid_3", () -> new Squid3Item());
	public static final RegistryObject<Item> CRUDEOIL = REGISTRY.register("crudeoil", () -> new CrudeoilItem());
	public static final RegistryObject<Item> EMPTYBOTTLE_1 = REGISTRY.register("emptybottle_1", () -> new Emptybottle1Item());
	public static final RegistryObject<Item> EMPTYBOTTLE_2 = REGISTRY.register("emptybottle_2", () -> new Emptybottle2Item());
	public static final RegistryObject<Item> EMPTYBOTTLE_3 = REGISTRY.register("emptybottle_3", () -> new Emptybottle3Item());
	public static final RegistryObject<Item> EMPTYBOTTLE_4 = REGISTRY.register("emptybottle_4", () -> new Emptybottle4Item());
	public static final RegistryObject<Item> PRIMARYVINEGAR = REGISTRY.register("primaryvinegar", () -> new PrimaryvinegarItem());
	public static final RegistryObject<Item> MAYONNAISE = REGISTRY.register("mayonnaise", () -> new MayonnaiseItem());
	public static final RegistryObject<Item> BOOK_1 = REGISTRY.register("book_1", () -> new Book1Item());
	public static final RegistryObject<Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final RegistryObject<Item> EMERALD_SWORD = REGISTRY.register("emerald_sword", () -> new EmeraldSwordItem());
	public static final RegistryObject<Item> EMERALD_SUIT_HELMET = REGISTRY.register("emerald_suit_helmet", () -> new EmeraldSuitItem.Helmet());
	public static final RegistryObject<Item> EMERALD_SUIT_CHESTPLATE = REGISTRY.register("emerald_suit_chestplate", () -> new EmeraldSuitItem.Chestplate());
	public static final RegistryObject<Item> EMERALD_SUIT_LEGGINGS = REGISTRY.register("emerald_suit_leggings", () -> new EmeraldSuitItem.Leggings());
	public static final RegistryObject<Item> EMERALD_SUIT_BOOTS = REGISTRY.register("emerald_suit_boots", () -> new EmeraldSuitItem.Boots());
	public static final RegistryObject<Item> COPPER_SUIT_HELMET = REGISTRY.register("copper_suit_helmet", () -> new CopperSuitItem.Helmet());
	public static final RegistryObject<Item> COPPER_SUIT_CHESTPLATE = REGISTRY.register("copper_suit_chestplate", () -> new CopperSuitItem.Chestplate());
	public static final RegistryObject<Item> COPPER_SUIT_LEGGINGS = REGISTRY.register("copper_suit_leggings", () -> new CopperSuitItem.Leggings());
	public static final RegistryObject<Item> COPPER_SUIT_BOOTS = REGISTRY.register("copper_suit_boots", () -> new CopperSuitItem.Boots());
	public static final RegistryObject<Item> COAL_FRAGMENT = REGISTRY.register("coal_fragment", () -> new CoalFragmentItem());
	public static final RegistryObject<Item> HONEYCOMB_BRIQUET = REGISTRY.register("honeycomb_briquet", () -> new HoneycombBriquetItem());
	public static final RegistryObject<Item> RAW_SHREDDED_SEAWEED = REGISTRY.register("raw_shredded_seaweed", () -> new RawShreddedSeaweedItem());
	public static final RegistryObject<Item> COOKED_SHREDDED_SEAWEED = REGISTRY.register("cooked_shredded_seaweed", () -> new CookedShreddedSeaweedItem());
	public static final RegistryObject<Item> RAW_SEAWEED_KNOT = REGISTRY.register("raw_seaweed_knot", () -> new RawSeaweedKnotItem());
	public static final RegistryObject<Item> COOKED_SEAWEED_KNOT = REGISTRY.register("cooked_seaweed_knot", () -> new CookedSeaweedKnotItem());
	public static final RegistryObject<Item> COLD_SEAWEED_SALAD = REGISTRY.register("cold_seaweed_salad", () -> new ColdSeaweedSaladItem());
	public static final RegistryObject<Item> RAW_SHREDDED_POTATO = REGISTRY.register("raw_shredded_potato", () -> new RawShreddedPotatoItem());
	public static final RegistryObject<Item> FRIED_SHREDDED_POTATO = REGISTRY.register("fried_shredded_potato", () -> new FriedShreddedPotatoItem());
	public static final RegistryObject<Item> CHOPPING_BOARD = block(FantasycraftModBlocks.CHOPPING_BOARD);
	public static final RegistryObject<Item> STOVE = block(FantasycraftModBlocks.STOVE);
	public static final RegistryObject<Item> KITCHEN_KNIFE = REGISTRY.register("kitchen_knife", () -> new KitchenKnifeItem());
	public static final RegistryObject<Item> SOUR_AND_SPICY_SHREDDED_POTATOES = REGISTRY.register("sour_and_spicy_shredded_potatoes", () -> new SourAndSpicyShreddedPotatoesItem());
	public static final RegistryObject<Item> RAW_BACON = REGISTRY.register("raw_bacon", () -> new RawBaconItem());
	public static final RegistryObject<Item> COOKED_BACON = REGISTRY.register("cooked_bacon", () -> new CookedBaconItem());
	public static final RegistryObject<Item> RAW_CHICKEN_NUGGETS = REGISTRY.register("raw_chicken_nuggets", () -> new RawChickenNuggetsItem());
	public static final RegistryObject<Item> COOKED_CHICKEN_NUGGETS = REGISTRY.register("cooked_chicken_nuggets", () -> new CookedChickenNuggetsItem());
	public static final RegistryObject<Item> RAW_PORK_NUGGETS = REGISTRY.register("raw_pork_nuggets", () -> new RawPorkNuggetsItem());
	public static final RegistryObject<Item> COOKED_PORK_NUGGETS = REGISTRY.register("cooked_pork_nuggets", () -> new CookedPorkNuggetsItem());
	public static final RegistryObject<Item> RAW_BEEF_NUGGETS = REGISTRY.register("raw_beef_nuggets", () -> new RawBeefNuggetsItem());
	public static final RegistryObject<Item> COOKED_BEEF_NUGGETS = REGISTRY.register("cooked_beef_nuggets", () -> new CookedBeefNuggetsItem());
	public static final RegistryObject<Item> RAW_MUTTON_NUGGETS = REGISTRY.register("raw_mutton_nuggets", () -> new RawMuttonNuggetsItem());
	public static final RegistryObject<Item> COOKED_MUTTON_NUGGETS = REGISTRY.register("cooked_mutton_nuggets", () -> new CookedMuttonNuggetsItem());
	public static final RegistryObject<Item> COOKED_EGG = REGISTRY.register("cooked_egg", () -> new CookedEggItem());
	public static final RegistryObject<Item> HALF_AN_EGG = REGISTRY.register("half_an_egg", () -> new HalfAnEggItem());
	public static final RegistryObject<Item> EMERALD_AXE = REGISTRY.register("emerald_axe", () -> new EmeraldAxeItem());
	public static final RegistryObject<Item> EMERALD_PICKAXE = REGISTRY.register("emerald_pickaxe", () -> new EmeraldPickaxeItem());
	public static final RegistryObject<Item> EMERALD_SHOVEL = REGISTRY.register("emerald_shovel", () -> new EmeraldShovelItem());
	public static final RegistryObject<Item> EMERALD_HOE = REGISTRY.register("emerald_hoe", () -> new EmeraldHoeItem());
	public static final RegistryObject<Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final RegistryObject<Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final RegistryObject<Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final RegistryObject<Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final RegistryObject<Item> PLATINUM_ORE = block(FantasycraftModBlocks.PLATINUM_ORE);
	public static final RegistryObject<Item> DEEPSLATE_PLATINUM_ORE = block(FantasycraftModBlocks.DEEPSLATE_PLATINUM_ORE);
	public static final RegistryObject<Item> RAW_PLATINUM = REGISTRY.register("raw_platinum", () -> new RawPlatinumItem());
	public static final RegistryObject<Item> PLATINUM_INGOT = REGISTRY.register("platinum_ingot", () -> new PlatinumIngotItem());
	public static final RegistryObject<Item> RAW_PLATINUM_BLOCK = block(FantasycraftModBlocks.RAW_PLATINUM_BLOCK);
	public static final RegistryObject<Item> PLATINUM_BLOCK = block(FantasycraftModBlocks.PLATINUM_BLOCK);
	public static final RegistryObject<Item> PLATINUM_NUGGET = REGISTRY.register("platinum_nugget", () -> new PlatinumNuggetItem());
	public static final RegistryObject<Item> PLATINUM_SWORD = REGISTRY.register("platinum_sword", () -> new PlatinumSwordItem());
	public static final RegistryObject<Item> PLATINUM_AXE = REGISTRY.register("platinum_axe", () -> new PlatinumAxeItem());
	public static final RegistryObject<Item> PLATINUM_SHOVEL = REGISTRY.register("platinum_shovel", () -> new PlatinumShovelItem());
	public static final RegistryObject<Item> PLATINUM_PICKAXE = REGISTRY.register("platinum_pickaxe", () -> new PlatinumPickaxeItem());
	public static final RegistryObject<Item> PLATINUM_HOE = REGISTRY.register("platinum_hoe", () -> new PlatinumHoeItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
