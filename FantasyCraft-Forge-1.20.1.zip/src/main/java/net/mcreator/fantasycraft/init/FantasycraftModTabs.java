
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.fantasycraft.FantasycraftMod;

public class FantasycraftModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FantasycraftMod.MODID);
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_1 = REGISTRY.register("fantasy_craft_1",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_1")).icon(() -> new ItemStack(FantasycraftModItems.COPPER_SWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.BOOK_1.get());
				tabData.accept(FantasycraftModBlocks.CHOPPING_BOARD.get().asItem());
				tabData.accept(FantasycraftModBlocks.STOVE.get().asItem());
				tabData.accept(FantasycraftModBlocks.PLATINUM_ORE.get().asItem());
				tabData.accept(FantasycraftModBlocks.DEEPSLATE_PLATINUM_ORE.get().asItem());
				tabData.accept(FantasycraftModBlocks.PLATINUM_BLOCK.get().asItem());
				tabData.accept(FantasycraftModBlocks.RAW_PLATINUM_BLOCK.get().asItem());
				tabData.accept(FantasycraftModItems.PLATINUM_NUGGET.get());
				tabData.accept(FantasycraftModItems.PLATINUM_INGOT.get());
				tabData.accept(FantasycraftModItems.RAW_PLATINUM.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_2 = REGISTRY.register("fantasy_craft_2",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_2")).icon(() -> new ItemStack(Items.PUMPKIN_PIE)).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.COOKED_EGG.get());
				tabData.accept(FantasycraftModItems.HALF_AN_EGG.get());
				tabData.accept(FantasycraftModItems.SQUID_2.get());
				tabData.accept(FantasycraftModItems.SQUID_3.get());
				tabData.accept(FantasycraftModItems.RAW_SHREDDED_SEAWEED.get());
				tabData.accept(FantasycraftModItems.COOKED_SHREDDED_SEAWEED.get());
				tabData.accept(FantasycraftModItems.RAW_SEAWEED_KNOT.get());
				tabData.accept(FantasycraftModItems.COOKED_SEAWEED_KNOT.get());
				tabData.accept(FantasycraftModItems.COLD_SEAWEED_SALAD.get());
				tabData.accept(FantasycraftModItems.RAW_SHREDDED_POTATO.get());
				tabData.accept(FantasycraftModItems.FRIED_SHREDDED_POTATO.get());
				tabData.accept(FantasycraftModItems.SOUR_AND_SPICY_SHREDDED_POTATOES.get());
				tabData.accept(FantasycraftModItems.RAW_BACON.get());
				tabData.accept(FantasycraftModItems.COOKED_BACON.get());
				tabData.accept(FantasycraftModItems.RAW_CHICKEN_NUGGETS.get());
				tabData.accept(FantasycraftModItems.COOKED_CHICKEN_NUGGETS.get());
				tabData.accept(FantasycraftModItems.RAW_PORK_NUGGETS.get());
				tabData.accept(FantasycraftModItems.COOKED_PORK_NUGGETS.get());
				tabData.accept(FantasycraftModItems.RAW_BEEF_NUGGETS.get());
				tabData.accept(FantasycraftModItems.COOKED_BEEF_NUGGETS.get());
				tabData.accept(FantasycraftModItems.RAW_MUTTON_NUGGETS.get());
				tabData.accept(FantasycraftModItems.COOKED_MUTTON_NUGGETS.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_3 = REGISTRY.register("fantasy_craft_3",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_3")).icon(() -> new ItemStack(FantasycraftModItems.VINEGAR.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.VINEGAR.get());
				tabData.accept(FantasycraftModItems.MAYONNAISE.get());
				tabData.accept(FantasycraftModItems.VEGETABLEOIL.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_4 = REGISTRY.register("fantasy_craft_4",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_4")).icon(() -> new ItemStack(FantasycraftModItems.HONEYCOMB_BRIQUET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.EMPTYBOTTLE_1.get());
				tabData.accept(FantasycraftModItems.EMPTYBOTTLE_3.get());
				tabData.accept(FantasycraftModItems.EMPTYBOTTLE_2.get());
				tabData.accept(FantasycraftModItems.PRIMARYVINEGAR.get());
				tabData.accept(FantasycraftModItems.EMPTYBOTTLE_4.get());
				tabData.accept(FantasycraftModItems.CRUDEOIL.get());
				tabData.accept(FantasycraftModItems.SQUID_1.get());
				tabData.accept(FantasycraftModItems.COAL_FRAGMENT.get());
				tabData.accept(FantasycraftModItems.HONEYCOMB_BRIQUET.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_5 = REGISTRY.register("fantasy_craft_5",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_5")).icon(() -> new ItemStack(Items.SPYGLASS)).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.KITCHEN_KNIFE.get());
				tabData.accept(FantasycraftModItems.COPPER_SHOVEL.get());
				tabData.accept(FantasycraftModItems.COPPER_PICKAXE.get());
				tabData.accept(FantasycraftModItems.COPPER_AXE.get());
				tabData.accept(FantasycraftModItems.COPPER_HOE.get());
				tabData.accept(FantasycraftModItems.EMERALD_SHOVEL.get());
				tabData.accept(FantasycraftModItems.EMERALD_PICKAXE.get());
				tabData.accept(FantasycraftModItems.EMERALD_AXE.get());
				tabData.accept(FantasycraftModItems.EMERALD_HOE.get());
				tabData.accept(FantasycraftModItems.PLATINUM_SHOVEL.get());
				tabData.accept(FantasycraftModItems.PLATINUM_PICKAXE.get());
				tabData.accept(FantasycraftModItems.PLATINUM_AXE.get());
				tabData.accept(FantasycraftModItems.PLATINUM_HOE.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_6 = REGISTRY.register("fantasy_craft_6",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_6")).icon(() -> new ItemStack(FantasycraftModItems.EMERALD_SWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.COPPER_SWORD.get());
				tabData.accept(FantasycraftModItems.EMERALD_SWORD.get());
				tabData.accept(FantasycraftModItems.PLATINUM_SWORD.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> FANTASY_CRAFT_7 = REGISTRY.register("fantasy_craft_7",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fantasycraft.fantasy_craft_7")).icon(() -> new ItemStack(FantasycraftModItems.EMERALD_SUIT_CHESTPLATE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FantasycraftModItems.COPPER_SUIT_HELMET.get());
				tabData.accept(FantasycraftModItems.COPPER_SUIT_CHESTPLATE.get());
				tabData.accept(FantasycraftModItems.COPPER_SUIT_LEGGINGS.get());
				tabData.accept(FantasycraftModItems.COPPER_SUIT_BOOTS.get());
				tabData.accept(FantasycraftModItems.EMERALD_SUIT_HELMET.get());
				tabData.accept(FantasycraftModItems.EMERALD_SUIT_CHESTPLATE.get());
				tabData.accept(FantasycraftModItems.EMERALD_SUIT_LEGGINGS.get());
				tabData.accept(FantasycraftModItems.EMERALD_SUIT_BOOTS.get());
			})

					.build());
}
