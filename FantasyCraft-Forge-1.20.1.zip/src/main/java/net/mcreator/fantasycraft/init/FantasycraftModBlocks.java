
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.fantasycraft.block.StoveBlock;
import net.mcreator.fantasycraft.block.RawPlatinumBlockBlock;
import net.mcreator.fantasycraft.block.PlatinumOreBlock;
import net.mcreator.fantasycraft.block.PlatinumBlockBlock;
import net.mcreator.fantasycraft.block.DeepslatePlatinumOreBlock;
import net.mcreator.fantasycraft.block.ChoppingBoardBlock;
import net.mcreator.fantasycraft.FantasycraftMod;

public class FantasycraftModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FantasycraftMod.MODID);
	public static final RegistryObject<Block> CHOPPING_BOARD = REGISTRY.register("chopping_board", () -> new ChoppingBoardBlock());
	public static final RegistryObject<Block> STOVE = REGISTRY.register("stove", () -> new StoveBlock());
	public static final RegistryObject<Block> PLATINUM_ORE = REGISTRY.register("platinum_ore", () -> new PlatinumOreBlock());
	public static final RegistryObject<Block> DEEPSLATE_PLATINUM_ORE = REGISTRY.register("deepslate_platinum_ore", () -> new DeepslatePlatinumOreBlock());
	public static final RegistryObject<Block> RAW_PLATINUM_BLOCK = REGISTRY.register("raw_platinum_block", () -> new RawPlatinumBlockBlock());
	public static final RegistryObject<Block> PLATINUM_BLOCK = REGISTRY.register("platinum_block", () -> new PlatinumBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
