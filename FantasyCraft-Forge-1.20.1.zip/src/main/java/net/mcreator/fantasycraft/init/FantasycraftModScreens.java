
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.fantasycraft.client.gui.Stove1Screen;
import net.mcreator.fantasycraft.client.gui.ChoppingBoard1Screen;
import net.mcreator.fantasycraft.client.gui.Book01Screen;
import net.mcreator.fantasycraft.client.gui.Book001Screen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class FantasycraftModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(FantasycraftModMenus.BOOK_01.get(), Book01Screen::new);
			MenuScreens.register(FantasycraftModMenus.BOOK_001.get(), Book001Screen::new);
			MenuScreens.register(FantasycraftModMenus.CHOPPING_BOARD_1.get(), ChoppingBoard1Screen::new);
			MenuScreens.register(FantasycraftModMenus.STOVE_1.get(), Stove1Screen::new);
		});
	}
}
