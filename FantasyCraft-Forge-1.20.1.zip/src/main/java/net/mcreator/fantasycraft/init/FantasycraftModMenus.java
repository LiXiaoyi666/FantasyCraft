
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fantasycraft.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.fantasycraft.world.inventory.Stove1Menu;
import net.mcreator.fantasycraft.world.inventory.ChoppingBoard1Menu;
import net.mcreator.fantasycraft.world.inventory.Book01Menu;
import net.mcreator.fantasycraft.world.inventory.Book001Menu;
import net.mcreator.fantasycraft.FantasycraftMod;

public class FantasycraftModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, FantasycraftMod.MODID);
	public static final RegistryObject<MenuType<Book01Menu>> BOOK_01 = REGISTRY.register("book_01", () -> IForgeMenuType.create(Book01Menu::new));
	public static final RegistryObject<MenuType<Book001Menu>> BOOK_001 = REGISTRY.register("book_001", () -> IForgeMenuType.create(Book001Menu::new));
	public static final RegistryObject<MenuType<ChoppingBoard1Menu>> CHOPPING_BOARD_1 = REGISTRY.register("chopping_board_1", () -> IForgeMenuType.create(ChoppingBoard1Menu::new));
	public static final RegistryObject<MenuType<Stove1Menu>> STOVE_1 = REGISTRY.register("stove_1", () -> IForgeMenuType.create(Stove1Menu::new));
}
